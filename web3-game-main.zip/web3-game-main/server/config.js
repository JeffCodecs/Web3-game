const defaultPassword = "rocks"
  
module.exports = defaultPassword;