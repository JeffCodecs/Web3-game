const config = {
    MongoUrl: "mongodb://127.0.0.1:27017/rockBlocks?gssapiServiceName=mongodb",
  };
  
  module.exports = config;