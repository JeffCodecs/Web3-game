import _ec from "elliptic";
var EC = _ec.ec;
export { EC };
//# sourceMappingURL=elliptic.js.map